let character;
let itemsNatural = [];
let pollutants = [];
let health = 100;
let score = 0;
let goal = 100; // Meta de pontos para ganhar

function setup() {
  createCanvas(800, 600);
  character = new Character();
  
  // Criar alguns itens naturais no campo
  for (let i = 0; i < 10; i++) {
    itemsNatural.push(new Item(random(50, 750), random(50, 550), 'natural'));
  }
  
  // Criar alguns poluentes na cidade
  for (let i = 0; i < 10; i++) {
    pollutants.push(new Item(random(50, 750), random(50, 550), 'pollutant'));
  }
}

function draw() {
  if (health <= 0) {
    gameOver();
    return;
  }
  
  if (score >= goal) {
    youWon();
    return;
  }

  background(200, 255, 200); // Cor de fundo que remete ao campo

  character.update();
  character.display();

  // Atualizar e desenhar itens naturais (bolinhas verdes)
  for (let item of itemsNatural) {
    item.update();
    item.display();
    if (character.collidesWith(item)) {
      score += 10;
      itemsNatural.splice(itemsNatural.indexOf(item), 1); // Remover item após pegar
    }
  }
  
  // Atualizar e desenhar poluentes (bolinhas vermelhas)
  for (let pollutant of pollutants) {
    pollutant.update();
    pollutant.display();
    if (character.collidesWith(pollutant)) {
      health -= 20;
      pollutants.splice(pollutants.indexOf(pollutant), 1); // Remover poluente após colisão
    }
  }

  // Mostrar a pontuação e saúde
  textSize(24);
  fill(0);
  text(`Pontos: ${score}`, 20, 30);
  text(`Saúde: ${health}`, 20, 60);
}

function keyPressed() {
  if (keyCode === LEFT_ARROW) {
    character.setDirection(-1, 0);
  } else if (keyCode === RIGHT_ARROW) {
    character.setDirection(1, 0);
  } else if (keyCode === UP_ARROW) {
    character.setDirection(0, -1);
  } else if (keyCode === DOWN_ARROW) {
    character.setDirection(0, 1);
  }
}

function gameOver() {
  background(255, 0, 0); // Fundo vermelho para game over
  textSize(48);
  fill(255);
  textAlign(CENTER, CENTER);
  text('GAME OVER', width / 2, height / 2);
  textSize(24);
  text(`Pontos: ${score}`, width / 2, height / 2 + 50);
}

function youWon() {
  background(0, 255, 0); // Fundo verde para vitória
  textSize(48);
  fill(255);
  textAlign(CENTER, CENTER);
  text('VOCÊ GANHOU!', width / 2, height / 2);
  textSize(24);
  text(`Pontos: ${score}`, width / 2, height / 2 + 50);
}

class Character {
  constructor() {
    this.x = width / 2;
    this.y = height / 2;
    this.size = 30;
    this.xSpeed = 0;
    this.ySpeed = 0;
  }

  setDirection(x, y) {
    this.xSpeed = x;
    this.ySpeed = y;
  }

  update() {
    this.x += this.xSpeed * 5;
    this.y += this.ySpeed * 5;

    // Limitar a movimentação dentro da tela
    this.x = constrain(this.x, 0, width - this.size);
    this.y = constrain(this.y, 0, height - this.size);
  }

  display() {
    fill(255, 0, 0); // Personagem vermelho
    noStroke();
    ellipse(this.x, this.y, this.size);
  }

  collidesWith(item) {
    let d = dist(this.x, this.y, item.x, item.y);
    return d < this.size / 2 + item.size / 2;
  }
}

class Item {
  constructor(x, y, type) {
    this.x = x;
    this.y = y;
    this.size = 20;
    this.type = type;
    this.xSpeed = random(-2, 2);  // Velocidade aleatória em X
    this.ySpeed = random(-2, 2);  // Velocidade aleatória em Y
  }

  update() {
    // Atualizar a posição do item (movendo de forma aleatória)
    this.x += this.xSpeed;
    this.y += this.ySpeed;

    // Se o item sair da tela, ele "rebate" na borda
    if (this.x < 0 || this.x > width) {
      this.xSpeed *= -1;
    }
    if (this.y < 0 || this.y > height) {
      this.ySpeed *= -1;
    }
  }

  display() {
    if (this.type === 'natural') {
      fill(0, 255, 0); // Cor verde para itens naturais
    } else {
      fill(255, 0, 0); // Cor vermelha para poluentes
    }
    noStroke();
    ellipse(this.x, this.y, this.size);
  }
}